package pavulurucis265;
/* 
 *  Name: ANIL PAVULURU
 *  CSU ID: 2782551 
 *  CIS 265: Pavuluru Assignment#4
 *  Description:In this assignment, you will create a Java program to create undergraduate or graduate students. 

*/
import static java.lang.System.*;

public class GradStudent extends Student{

private  String college;

public GradStudent(String name,int id, float gpa,String _college){

super(name,id,gpa);
college=_college;
}

public void printStudent(){
super.printStudent();
out.println("College Graduated:"+ college);
}
}



