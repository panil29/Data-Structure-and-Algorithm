package pavulurucis265;
/* 
 *  Name: ANIL PAVULURU
 *  CSU ID: 2782551 
 *  CIS 265: Pavuluru Assignment#4
 *  Description:In this assignment, you will create a Java program to create undergraduate or graduate students. 

*/

import static java.lang.System.*;
import java.util.ArrayList;
import java.util.Scanner;
 
 
public class PavuluruAssignment4{

    public static void main(String args[]){
            ArrayList<Student>students=new ArrayList<Student>();
            Scanner s=new Scanner(System.in);
            String input;
             while (true) {
             out.print("DO you have more Students to Enter(Y for yes, N for no);");
             input = s.nextLine();
             if(input.equals("Y") || input.equals("N")){
             if(input.equals("N")){
              break;
              } else {
                      while (true) {
                      out.print("Undergraduate or Graduate?(U for undergraduate, G for graduate):");
                      input = s.nextLine();
                      if(input.equals("U") || input.equals("G")) {
                      if(input.equalsIgnoreCase("U")){
                      Student student=createUnderGradStudent(s);
                      students.add(student);
                       } else {
                              Student student=createGradStudent(s);
                              students.add(student);
                              }
                               break;
                            }
                       }
                    }
                 }
              }
 while(true) {
             
           out.print("Enter a student ID(enter o to quit): ");
           int searchvalue=s.nextInt();
           if(searchvalue == 0) {
                               out.println("Goodbye!");
                               break;
              } else if(searchvalue > 0){
              boolean isIdFound= false;
              for(int i=0;i < students.size();i++){
                    if(searchvalue==students.get(i).getID()){
                    isIdFound=true;
                    students.get(i).printStudent();
                   }
                  } 
                   if(!isIdFound)
                    out.println("Student ID "+searchvalue+"not found:");
                 } else {
                 out.println("Invalid Input");
                 }
             }
             s.close();
        }
                                     
private static  Student createUnderGradStudent(Scanner s){
out.print("Student name:");
String name=s.nextLine();
int id;
while(true){
out.print("Student Id:");
try{
id=s.nextInt();
s.nextLine();
break;
}catch(Exception e){
s.nextLine();
out.println("Invalid ID!(ID should be in integer value)");
}
}
float gpa;
while(true){
out.print("Student GPA:");
try{
gpa=s.nextFloat();
s.nextLine();
break;
}catch (Exception e){
s.nextLine();
out.println("Invalid GPA!(ID should be in float value)");
}
}
boolean isTransfer;
while(true){
out.print("Is student a transfer student?(Y for yes,N for no):");
String input=s.nextLine();
if(input.equals("Y") || input.equals("N")){
if(input.equals("N")){
isTransfer=false;
}
else{
isTransfer=true;
}
break;
}
}
Student student= new UndergradStudent(name, id, gpa, isTransfer);
return student;
}


private static  Student createGradStudent(Scanner s){
out.print("Student name:");
String name=s.nextLine();
int id;
while(true){
out.print("Student Id:");
try{
id=s.nextInt();
s.nextLine();
break;
}catch(Exception e){
s.nextLine();
out.println("Invalid ID!(ID should be in integer value)");
}
}
float gpa;
while(true){
out.print("Student GPA:");
try{
gpa=s.nextFloat();
s.nextLine();
break;
}catch (Exception e){
s.nextLine();
out.println("Invalid GPA!(ID should be in float value)");
}
}
out.print("What college did the studnet graduate from:");
String college=s.nextLine();
Student student= new GradStudent(name, id, gpa, college);
return student;
}
}








