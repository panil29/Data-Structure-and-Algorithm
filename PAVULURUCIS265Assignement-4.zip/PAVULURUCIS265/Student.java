package pavulurucis265;
/* 
 *  Name: ANIL PAVULURU
 *  CSU ID: 2782551 
 *  CIS 265: Pavuluru Assignment#4
 *  Description:In this assignment, you will create a Java program to create undergraduate or graduate students. 

*/

import static java.lang.System.*;

public class Student{

     private String name;
     private int id;
     private float gpa;
 
     public Student(){
         name="";
         id=0;
         gpa=0;
    }

 public Student(String _name,int _id,float _gpa){
        name=_name;
        id=_id;
        gpa=_gpa;
}

 public int getID(){
        return id;
}        
        

public void printStudent() {
out.println(" Student name: "+name);
out.println(" Student ID: "+id);
out.println(" Student GPA: "+gpa);

}
}



