package pavulurucis265;
/* 
 *  Name: ANIL PAVULURU
 *  CSU ID: 2782551 
 *  CIS 265: Pavuluru Assignment#4
 *  Description:In this assignment, you will create a Java program to create undergraduate or graduate students. 

*/
import static java.lang.System.*;

public class UndergradStudent extends Student{

private boolean isTransfer;

public UndergradStudent(String name,int id, float gpa,boolean _isTransfer){

       super(name,id,gpa);
        isTransfer=_isTransfer;
}

   public void printStudent(){
   super.printStudent();
   out.println("Transfer Student:"+ isTransfer);
}
}