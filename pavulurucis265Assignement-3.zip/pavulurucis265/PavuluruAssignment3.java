package pavulurucis265;

/* 
 *  Name: ANIL PAVULURU
 *  CSU ID: 2782551 
 *  CIS 265: Pavuluru Assignment#3
 *  Description:In this assignment, you will create a Java program to create an array of students to search. The program
must implement a student class as specified in the following UML diagram.
   Student
* -name: String
* -id: int
* -gpa: float
* <<constructor>> +Student(String, int, float)
* +pringStudent():void
* +getID():int
 
*Note: I have written the code for the extra bonus points using additional features
 */

import java.util.Scanner;
public class PavuluruAssignment3{

//  function
public static void main(String[] args) {
Scanner scan = new Scanner(System.in);

// ask the programmer to enter  number of students
System.out.print("How many students do you have(1-10): ");
int numOfStudents = scan.nextInt();

//input right go or else not print the pop up and exit
if (numOfStudents < 1 || numOfStudents > 10) {
System.out.println("I cannot create " + numOfStudents + " students!");
System.exit(-1);
}

// creation of array for student objects
Student array[] = new Student[numOfStudents];

// programmer input details
for (int i = 0; i < numOfStudents; i++) {
System.out.print("Student " + (i + 1) + " name:");
scan.nextLine();
String name = scan.nextLine();

// duplicate id searching(Extra Bonus)
int id;
while(true){
System.out.print("Student " + (i + 1) + " ID:");
id = scan.nextInt();
boolean isDuplicate = false;
if(i>0)
	for(int j=0;j<i;j++){
		isDuplicate =  false;
			if(array[j].getID()!=0 && id==array[j].getID()){
				System.out.println("Student ID "+id+" already exist! Please retry!");
				isDuplicate = true;
				break;
			}
	}
	if(!isDuplicate){
		break;
	}
}
//duplicate id searching terminate when we enter right id's(Extra BOnus)

System.out.print("Student " + (i + 1) + " GPA:");
float gpa = scan.nextFloat();
array[i] = new Student(name, id, gpa);
}

int searchID;
boolean notFound;

// search student info based on our input
while (true) {
notFound = true;
System.out.print("Enter a Student ID to search: ");
searchID = scan.nextInt();

//  id is 0 then exit 
if (searchID == 0) {
break;
}

//  linearly search by the array of student 
for (Student student : array) {
// find means  print details
if (student.getID() == searchID) {
student.printStudent();
notFound = false;
break;
}
}

// student is not find  print goodbyeeeee 
if (notFound) {
System.out.println("Student ID " + searchID + " not found.");
}
}
System.out.println("Goodbye!");
}
}
