package pavulurucis265;


/* 
 *  Name: ANIL PAVULURU
 *  CSU ID: 2782551 
 *  CIS 265: Pavuluru Assignment#3
 *  Description:In this assignment, you will create a Java program to create an array of students to search. The program
must implement a student class as specified in the following UML diagram.
   Student
* -name: String
* -id: int
* -gpa: float
* <<constructor>> +Student(String, int, float)
* +pringStudent():void
* +getID():int
 
*Note: I have written the code for the extra bonus points using additional features
*/

public class Student {

// students variables
private String name;
private int id=0;
private float gpa;

// constructor of student class
Student(String Name, int ID, float Gpa) {
this.name = Name;
this.id = ID;
this.gpa = Gpa;
}

//  print student details
public void printStudent() {
System.out.println("Student name: " + name + ", Student ID: " + id + ", Student GPA: " + gpa);
}

//  get student ID
public int getID() {
return id;
}
}