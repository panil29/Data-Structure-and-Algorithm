package pavulurucis265;
/* 
 *  Name: ANIL PAVULURU
 *  CSU ID: 2782551 
 *  CIS 265: Pavuluru Assignment#5
 *  Description:In this assignment, you will create a Java program to read undergraduate and graduate students from an input
file, and write them in reverse order to an output file. 
 

*/

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;

public class PavuluruAssignement5 {

	public static void main(String args[]) throws IOException {

		if (args.length != 2) {
			System.out.println(" Incorrect number of arguments passed. Here are the correct format");//write correct error message
			System.exit(0);

		}
		String inputFileName = args[0];
		String outFileName = args[1];

		ArrayList<Student> students = new ArrayList<Student>();

		BufferedReader reader = new BufferedReader(new FileReader("F:\\" + inputFileName));
		String line = reader.readLine();

		while (line != null) {
			boolean invalidInput = false;
			StringTokenizer st = new StringTokenizer(line, ",");
			int fieldsCount = st.countTokens();
			Student student = null;

			if (fieldsCount != 5) {
				invalidInput = true;
				System.out.println("Invalid input: " + line);
			} else {
				String name = null;
				String id = null;
				String gpa = null;
				String grad = null;
				String status = null;
				while (st.hasMoreTokens()) {
					name = st.nextToken();
					id = st.nextToken();
					gpa = st.nextToken();
					grad = st.nextToken();
					status = st.nextToken();
				}
				try {
					if ("graduate".equalsIgnoreCase(grad)) {
						student = new GradStudent(name, Integer.valueOf(id), Float.parseFloat(gpa), status);
					} else if ("undergraduate".equalsIgnoreCase(grad)) {
						if (status.equalsIgnoreCase("true") || status.equalsIgnoreCase("false"))
							student = new UndergradStudent(name, Integer.valueOf(id), Float.parseFloat(gpa), status);
						else
							throw new IOException();
					} else
						throw new IOException();
				} catch (Exception e) {
					invalidInput = true;
					System.out.println(" Invalid input: " + line);
				}
			}
			if (!invalidInput)
				students.add(student);

			line = reader.readLine();
		}
		reader.close();

		FileWriter fileWriter = new FileWriter("F:\\" + outFileName);
		PrintWriter output = new PrintWriter(fileWriter);

		for (int i = students.size() - 1; i >= 0; i--) {
			students.get(i).printStudent(output);
		}

		output.close();

	}
}
