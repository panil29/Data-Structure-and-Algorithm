package pavulurucis265;
/* 
 *  Name: ANIL PAVULURU
 *  CSU ID: 2782551 
 *  CIS 265: Pavuluru Assignment#5
 *  Description:In this assignment, you will create a Java program to read undergraduate and graduate students from an input
file, and write them in reverse order to an output file. 
 

*/

import static java.lang.System.out;

import java.io.PrintWriter;

public abstract class Student {

	private String name;
	private int id;
	private float gpa;

	public Student() {

		super();

	}

	public Student(String _name, int _id, float _gpa) {

		this.name = _name;
		this.id = _id;
		this.gpa = _gpa;
	}

	public void printStudent() {

		out.printf(name + "," + id + "," + gpa);
	}

	public int getID() {
		return id;
	}

	public void printStudent(PrintWriter output) {
		// TODO Auto-generated method stub
		output.printf(name + "," + id + "," + gpa);
	}

}
