package pavulurucis265;
/* 
 *  Name: ANIL PAVULURU
 *  CSU ID: 2782551 
 *  CIS 265: Pavuluru Assignment#5
 *  Description:In this assignment, you will create a Java program to read undergraduate and graduate students from an input
file, and write them in reverse order to an output file. 
 

*/

import static java.lang.System.out;

import java.io.PrintWriter;

public class GradStudent extends Student {

	private String college;

	public GradStudent(String _name, int _id, float _gpa, String _college) {
		super(_name, _id, _gpa);

		college = _college;
	}

	public void printStudent() {
		out.println(",graduate," + college + "\n");
	}

	public void printStudent(PrintWriter output) {
		super.printStudent(output);
		output.printf(",graduate," + college + "\n");
	}
}