package pavulurucis265;
/* 
 *  Name: ANIL PAVULURU
 *  CSU ID: 2782551 
 *  CIS 265: Pavuluru Assignment#5
 *  Description:In this assignment, you will create a Java program to read undergraduate and graduate students from an input
file, and write them in reverse order to an output file. 
 

*/

import static java.lang.System.out;

import java.io.PrintWriter;

public class UndergradStudent extends Student {

	private String isTransfer;

	public UndergradStudent(String _name, int _id, float _gpa, String _isTransfer) {
		super(_name, _id, _gpa);

		isTransfer = _isTransfer;
	}

	public void printStudent() {

		out.println(",undergraduate," + isTransfer + "\n");
	}

	public void printStudent(PrintWriter output) {

		super.printStudent(output);
		output.printf(",undergraduate," + isTransfer + "\n");
	}

}
