package pavulurucis265;

import java.util.Comparator;

public class StudentGPAComparator implements Comparator<Student> {

	@Override
	public int compare(Student s1, Student s2) {
		// TODO Auto-generated method stub

		return Float.compare(s1.getGpa(), s2.getGpa());
	}

}
